const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  PutCommand,
  GetCommand,
  ScanCommand,
  UpdateCommand,
  DeleteCommand,
  QueryCommand,
} = require("@aws-sdk/lib-dynamodb");
const { randomUUID } = require("crypto");

const client = new DynamoDBClient({ region: process.env.AWS_REGION || "us-east-1" });
const docClient = DynamoDBDocumentClient.from(client);

const TABLE_NAME = process.env.TABLE_NAME || "Contactos";

const headers = {
  "Content-Type": "application/json",
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type,Authorization",
  "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
};

const response = (statusCode, body) => ({
  statusCode,
  headers,
  body: JSON.stringify(body),
});

// ─── CREATE ───────────────────────────────────────────────────────────────────
async function createContacto(data) {
  const { nombre, email, telefono, empresa } = data;

  if (!nombre || nombre.trim().length < 2) {
    return response(400, { error: "El nombre es requerido (mínimo 2 caracteres)." });
  }
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return response(400, { error: "Email inválido." });
  }
  if (telefono && !/^\+?[\d\s\-()]{7,15}$/.test(telefono)) {
    return response(400, { error: "Teléfono inválido." });
  }

  const item = {
    contactoId: randomUUID(),
    nombre: nombre.trim(),
    email: email.toLowerCase().trim(),
    telefono: telefono ? telefono.trim() : null,
    empresa: empresa ? empresa.trim() : null,
    creadoEn: new Date().toISOString(),
    actualizadoEn: new Date().toISOString(),
  };

  await docClient.send(new PutCommand({ TableName: TABLE_NAME, Item: item }));
  return response(201, { message: "Contacto creado exitosamente.", contacto: item });
}

// ─── READ (all) ───────────────────────────────────────────────────────────────
async function listarContactos(queryParams = {}) {
  const { filtro, limite } = queryParams;
  const params = { TableName: TABLE_NAME };

  if (limite) params.Limit = parseInt(limite);

  const result = await docClient.send(new ScanCommand(params));
  let items = result.Items || [];

  if (filtro) {
    const f = filtro.toLowerCase();
    items = items.filter(
      (c) =>
        c.nombre?.toLowerCase().includes(f) ||
        c.email?.toLowerCase().includes(f) ||
        c.empresa?.toLowerCase().includes(f)
    );
  }

  items.sort((a, b) => new Date(b.creadoEn) - new Date(a.creadoEn));

  return response(200, { contactos: items, total: items.length });
}

// ─── READ (one) ───────────────────────────────────────────────────────────────
async function obtenerContacto(id) {
  if (!id) return response(400, { error: "ID requerido." });

  const result = await docClient.send(
    new GetCommand({ TableName: TABLE_NAME, Key: { contactoId: id } })
  );

  if (!result.Item) return response(404, { error: "Contacto no encontrado." });
  return response(200, { contacto: result.Item });
}

// ─── UPDATE ───────────────────────────────────────────────────────────────────
async function actualizarContacto(id, data) {
  if (!id) return response(400, { error: "ID requerido." });

  const { nombre, email, telefono, empresa } = data;

  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return response(400, { error: "Email inválido." });
  }

  // Verificar que existe
  const existing = await docClient.send(
    new GetCommand({ TableName: TABLE_NAME, Key: { contactoId: id } })
  );
  if (!existing.Item) return response(404, { error: "Contacto no encontrado." });

  const updateExpression = [];
  const expressionAttributeNames = {};
  const expressionAttributeValues = {};

  if (nombre) {
    updateExpression.push("#nombre = :nombre");
    expressionAttributeNames["#nombre"] = "nombre";
    expressionAttributeValues[":nombre"] = nombre.trim();
  }
  if (email) {
    updateExpression.push("#email = :email");
    expressionAttributeNames["#email"] = "email";
    expressionAttributeValues[":email"] = email.toLowerCase().trim();
  }
  if (telefono !== undefined) {
    updateExpression.push("#telefono = :telefono");
    expressionAttributeNames["#telefono"] = "telefono";
    expressionAttributeValues[":telefono"] = telefono;
  }
  if (empresa !== undefined) {
    updateExpression.push("#empresa = :empresa");
    expressionAttributeNames["#empresa"] = "empresa";
    expressionAttributeValues[":empresa"] = empresa;
  }

  updateExpression.push("#actualizadoEn = :actualizadoEn");
  expressionAttributeNames["#actualizadoEn"] = "actualizadoEn";
  expressionAttributeValues[":actualizadoEn"] = new Date().toISOString();

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TABLE_NAME,
      Key: { contactoId: id },
      UpdateExpression: "SET " + updateExpression.join(", "),
      ExpressionAttributeNames: expressionAttributeNames,
      ExpressionAttributeValues: expressionAttributeValues,
      ReturnValues: "ALL_NEW",
      ConditionExpression: "attribute_exists(contactoId)",
    })
  );

  return response(200, {
    message: "Contacto actualizado exitosamente.",
    contacto: result.Attributes,
  });
}

// ─── DELETE ───────────────────────────────────────────────────────────────────
async function eliminarContacto(id) {
  if (!id) return response(400, { error: "ID requerido." });

  const existing = await docClient.send(
    new GetCommand({ TableName: TABLE_NAME, Key: { contactoId: id } })
  );
  if (!existing.Item) return response(404, { error: "Contacto no encontrado." });

  await docClient.send(
    new DeleteCommand({
      TableName: TABLE_NAME,
      Key: { contactoId: id },
      ConditionExpression: "attribute_exists(contactoId)",
    })
  );

  return response(200, {
    message: "Contacto eliminado exitosamente.",
    contactoId: id,
  });
}

// ─── HANDLER ──────────────────────────────────────────────────────────────────
exports.handler = async (event) => {
  console.log("Event:", JSON.stringify(event, null, 2));

  try {
    const method = event.httpMethod;
    const path = event.path || "";
    const pathParts = path.split("/").filter(Boolean);
    const id = pathParts[1] || null; // /contactos/{id}
    const body = event.body ? JSON.parse(event.body) : {};
    const queryParams = event.queryStringParameters || {};

    if (method === "OPTIONS") return response(200, {});

    if (method === "GET" && !id) return await listarContactos(queryParams);
    if (method === "GET" && id) return await obtenerContacto(id);
    if (method === "POST") return await createContacto(body);
    if (method === "PUT" && id) return await actualizarContacto(id, body);
    if (method === "DELETE" && id) return await eliminarContacto(id);

    return response(404, { error: "Ruta no encontrada." });
  } catch (err) {
    console.error("Error:", err);

    if (err.name === "ConditionalCheckFailedException") {
      return response(409, { error: "Conflicto: el recurso fue modificado o no existe." });
    }
    if (err.name === "ValidationException") {
      return response(400, { error: "Datos inválidos para DynamoDB.", detalle: err.message });
    }
    if (err.name === "ResourceNotFoundException") {
      return response(503, { error: "Tabla DynamoDB no encontrada. Verifique la configuración." });
    }

    return response(500, { error: "Error interno del servidor.", detalle: err.message });
  }
};
